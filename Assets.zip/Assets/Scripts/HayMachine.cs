using UnityEngine;

public class HayMachine : MonoBehaviour
{
    [SerializeField] float movementSpeed;
    [SerializeField] float horizontalBoundary = 22;
    [SerializeField] GameObject hayBalePrefab;
    [SerializeField] Transform haySpawnpoint; // Changed from spawnPoint to match tutorial
    [SerializeField] float shootInterval; // Added shoot interval
    private float shootTimer; // Added timer variable

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        UpdateMovement();
        UpdateShooting(); // Changed to use the shooting method from tutorial
    }

    private void UpdateMovement()
    {
        float horizontalInput = Input.GetAxisRaw("Horizontal");
        
        if (horizontalInput < 0 && transform.position.x > -horizontalBoundary)
        {
            transform.Translate(transform.right * -movementSpeed * Time.deltaTime);
        }
        else if (horizontalInput > 0 && transform.position.x < horizontalBoundary)
        {
            transform.Translate(transform.right * movementSpeed * Time.deltaTime);
        }
    }

    private void UpdateShooting()
    {
        shootTimer -= Time.deltaTime; // Decrease timer

        if (shootTimer <= 0 && Input.GetKey(KeyCode.Space)) // Check timer and input
        {
            shootTimer = shootInterval; // Reset timer
            ShootHay(); // Shoot hay
        }
    }

    private void ShootHay()
    {
        Instantiate(hayBalePrefab, haySpawnpoint.position, Quaternion.identity);
        SoundManager.Instance.PlayShootClip();  //Extra (sound effect)
    }
}