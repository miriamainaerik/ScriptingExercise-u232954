using UnityEngine;

public class HayBaleMovement : MonoBehaviour
{
    [SerializeField] float movementSpeed = 50; 


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(new Vector3(0,0,movementSpeed * Time.deltaTime), Space.World);
    }
}
