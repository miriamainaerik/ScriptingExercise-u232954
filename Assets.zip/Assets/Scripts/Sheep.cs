using UnityEngine;

public class Sheep : MonoBehaviour
{
    public float runSpeed = 10;
    public float gotHayDestroyDelay = 1;
    public float dropDestroyDelay = 4;
    public float heartOffset = 4;
    public GameObject heartPrefab;
    
    private bool hitByHay;
    private bool hasDropped;  // NEW
    private Collider myCollider;
    private Rigidbody myRigidbody;
    private SheepSpawner sheepSpawner;
    
    void Start()
    {
        myCollider = GetComponent<Collider>();
        myRigidbody = GetComponent<Rigidbody>();
    }
    
    void Update()
    {
        transform.Translate(Vector3.forward * runSpeed * Time.deltaTime);
    }
    
    public void SetSpawner(SheepSpawner spawner)
    {
        sheepSpawner = spawner;
    }
    
    private void HitByHay()
    {
        hitByHay = true;
        runSpeed = 0;
        
        SoundManager.Instance.PlaySheepHitClip();
        GameStateManager.Instance.SavedSheep();
        
        if (heartPrefab != null)
        {
            Vector3 heartPosition = transform.position + new Vector3(0, heartOffset, 0);
            Instantiate(heartPrefab, heartPosition, Quaternion.identity);
        }
        
        TweenScale tweenScale = gameObject.AddComponent<TweenScale>();
        tweenScale.targetScale = 0;
        tweenScale.timeToReachTarget = gotHayDestroyDelay;
        
        if (sheepSpawner != null) sheepSpawner.RemoveSheepFromList(gameObject);
        Destroy(gameObject, gotHayDestroyDelay);
    }
    
    private void Drop()
    {
        if (hasDropped) return;  // FIX: Prevents double counting
        hasDropped = true;
        
        SoundManager.Instance.PlaySheepDroppedClip();
        GameStateManager.Instance.DroppedSheep();
        
        if (sheepSpawner != null) sheepSpawner.RemoveSheepFromList(gameObject);
        myRigidbody.isKinematic = false;
        myCollider.isTrigger = false;
        Destroy(gameObject, dropDestroyDelay);
    }
    
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Hay") && !hitByHay)
        {
            Destroy(other.gameObject);
            HitByHay();
        }
        else if (other.CompareTag("DropSheep"))
        {
            Drop();
        }
    }
}